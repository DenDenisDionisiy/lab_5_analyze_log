﻿namespace LogAnalyzer
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblCode200 = new Label();
            lblCode404 = new Label();
            lblCode403 = new Label();
            lblUniqueIPs = new Label();
            lblGooglebot = new Label();
            lblYandexbot = new Label();
            openFileDialog1 = new OpenFileDialog();
            listBoxTopIPs = new ListBox();
            btnOpenFile = new Button();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            SuspendLayout();
            // 
            // lblCode200
            // 
            lblCode200.AutoSize = true;
            lblCode200.Location = new Point(189, 75);
            lblCode200.Name = "lblCode200";
            lblCode200.Size = new Size(253, 37);
            lblCode200.TabIndex = 0;
            lblCode200.Text = "Успешные (200): —";
            // 
            // lblCode404
            // 
            lblCode404.AutoSize = true;
            lblCode404.Location = new Point(189, 162);
            lblCode404.Name = "lblCode404";
            lblCode404.Size = new Size(228, 37);
            lblCode404.TabIndex = 1;
            lblCode404.Text = "Ошибки (404): —";
            // 
            // lblCode403
            // 
            lblCode403.AutoSize = true;
            lblCode403.Location = new Point(189, 256);
            lblCode403.Name = "lblCode403";
            lblCode403.Size = new Size(268, 37);
            lblCode403.TabIndex = 2;
            lblCode403.Text = "Запрещено (403): —";
            // 
            // lblUniqueIPs
            // 
            lblUniqueIPs.AutoSize = true;
            lblUniqueIPs.Location = new Point(189, 357);
            lblUniqueIPs.Name = "lblUniqueIPs";
            lblUniqueIPs.Size = new Size(237, 37);
            lblUniqueIPs.TabIndex = 3;
            lblUniqueIPs.Text = "Уникальные IP: —";
            // 
            // lblGooglebot
            // 
            lblGooglebot.AutoSize = true;
            lblGooglebot.Location = new Point(189, 456);
            lblGooglebot.Name = "lblGooglebot";
            lblGooglebot.Size = new Size(186, 37);
            lblGooglebot.TabIndex = 4;
            lblGooglebot.Text = "Googlebot: —";
            // 
            // lblYandexbot
            // 
            lblYandexbot.AutoSize = true;
            lblYandexbot.Location = new Point(189, 547);
            lblYandexbot.Name = "lblYandexbot";
            lblYandexbot.Size = new Size(181, 37);
            lblYandexbot.TabIndex = 5;
            lblYandexbot.Text = "YandexBot: —";
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            openFileDialog1.FileOk += openFileDialog1_FileOk;
            // 
            // listBoxTopIPs
            // 
            listBoxTopIPs.FormattingEnabled = true;
            listBoxTopIPs.ItemHeight = 37;
            listBoxTopIPs.Location = new Point(531, 60);
            listBoxTopIPs.Name = "listBoxTopIPs";
            listBoxTopIPs.Size = new Size(921, 596);
            listBoxTopIPs.TabIndex = 6;
            // 
            // btnOpenFile
            // 
            btnOpenFile.Location = new Point(162, 774);
            btnOpenFile.Name = "btnOpenFile";
            btnOpenFile.Size = new Size(295, 52);
            btnOpenFile.TabIndex = 7;
            btnOpenFile.Text = "Открыть файл лога";
            btnOpenFile.UseVisualStyleBackColor = true;
            btnOpenFile.Click += btnOpenFile_Click_1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(15F, 37F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1894, 1054);
            Controls.Add(btnOpenFile);
            Controls.Add(listBoxTopIPs);
            Controls.Add(lblYandexbot);
            Controls.Add(lblGooglebot);
            Controls.Add(lblUniqueIPs);
            Controls.Add(lblCode403);
            Controls.Add(lblCode404);
            Controls.Add(lblCode200);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblCode200;
        private Label lblCode404;
        private Label lblCode403;
        private Label lblUniqueIPs;
        private Label lblGooglebot;
        private Label lblYandexbot;
        private OpenFileDialog openFileDialog1;
        private ListBox listBoxTopIPs;
        private Button btnOpenFile;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}
