using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace LogAnalyzer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            this.Text = "���������� �����";
        }

        private void btnOpenFile_Click_1(object sender, EventArgs e)
        {
            // ���������� ��� �����
            openFileDialog1.Filter = "Log Files (*.log;*.txt)|*.log;*.txt|All files (*.*)|*.*";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog1.FileName;
                ParseLogFile(filePath);
            }
        }

        private void ParseLogFile(string filePath)
        {
            // ��������
            int count200 = 0;
            int count404 = 0;
            int count403 = 0;
            int countGoogle = 0;
            int countYandex = 0;

            
            Dictionary<string, int> ipCounter = new Dictionary<string, int>();

            
            using (StreamReader sr = new StreamReader(filePath))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    
                    string[] parts = line.Split(' ');
                    if (parts.Length < 10) continue; 

                    // IP-����� 
                    string ip = parts[1];
                    if (ipCounter.ContainsKey(ip))
                        ipCounter[ip]++;
                    else
                        ipCounter[ip] = 1;

                    // HTTP-��� ������ 
                    string statusCode = parts[9];
                    if (statusCode == "200") count200++;
                    else if (statusCode == "404") count404++;
                    else if (statusCode == "403") count403++;

                    // User-Agent
                    if (line.ToLower().Contains("googlebot")) countGoogle++;
                    if (line.ToLower().Contains("yandexbot")) countYandex++;
                }
            }

            // ����� �� �����
            lblCode200.Text = $"�������� (200): {count200}";
            lblCode404.Text = $"������ (404): {count404}";
            lblCode403.Text = $"��������� (403): {count403}";
            lblUniqueIPs.Text = $"���������� IP: {ipCounter.Count}";
            lblGooglebot.Text = $"Googlebot: {countGoogle}";
            lblYandexbot.Text = $"YandexBot: {countYandex}";

            
            listBoxTopIPs.Items.Clear();
            var topIPs = ipCounter.OrderByDescending(pair => pair.Value).Take(10);

            foreach (var ipRow in topIPs)
            {
                listBoxTopIPs.Items.Add($"{ipRow.Key} � {ipRow.Value} ��������");
            }

            MessageBox.Show("������ ���� ������� ��������!", "������", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

       

        private void openFileDialog1_FileOk(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }
    }
}